<?php 


	if(isset($_POST['submit'])){

		$busname 	= $_POST['busname'];
		$number		= $_POST['number'];
		$destination 	= $_POST['destination'];

		if($busname != ""){
			if($number != ""){
				if($destination!=""){
                            $myfile = fopen('../models/addbus.txt', 'r');
                            $id=0;
                            while(!feof($myfile)){
        
                                $data = fgets($myfile);
                                $id++;
                            }
        
                            $myfile = fopen('../models/addbus.txt', 'a');
                            $myuser = $id. "|".$busname."|".$number."|".$destination."\r\n";
                            fwrite($myfile, $myuser);
                            fclose($myfile);
        
                            header('location: ../views/dashboard.php');
                        }else{

                            echo "Invalid Bus name.....";

                        }
                    }else{
                        echo "Invalid bus number....";
                    
                    }
				}else{
					echo "invalid destination....";
				}
			}
?>
<?php
    include "../models/db.php";
    if(isset($_POST["submit"])){
        //$minimum=2;
        $usernames= $_POST["usernames"];
        $passwords= $_POST["passwords"];
        $gmails= $_POST["gmails"];
        $phonenumber= $_POST['phonenumber'];
        //if(strlen($passwords) < $minimum){
          //  echo "Password is too much short";
       // }
    $query = "INSERT INTO bus_manager(usernames,passwords,gmails,phonenumber)";
    $query .= "VALUES ('$usernames','$passwords','$gmails','$phonenumber')";
    $result = mysqli_query($connection,$query);
    }

?>
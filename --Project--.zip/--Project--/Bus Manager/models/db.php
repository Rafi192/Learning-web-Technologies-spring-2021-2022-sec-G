<?php
	$connection = mysqli_connect('localhost','root','','transport');
	if($connection){
        echo "Manager added";
		// header('location: ../views/dashboard.php');
	}else{
        die("Database connection failed");
    }
    

?>
<?php
	$connection = mysqli_connect('localhost','root','','transport');
    $query = "SELECT * FROM customer";
    $result = mysqli_query($connection,$query);
   

?>
let name= document.getElementById('uname')
let password=document.getElementById('pass')
let emails=document.getElementById('emails')
let phone=document.getElementById('phone')

let errorElemnet=document.getElementById('error')

form.addEventListener('submit',(error)=>{
	if(message.length>0){
        error.preventDefault()
        errorElemnet.innerText=message.join(',')
    }

    let message=[]
    if (uname.value==='' || uname.value==null){
        message.push('Name is required')

    }
    else if(password.value.length<8 && password.value.length >0){

        message.push('password must be less than 20 and greater than 8 characters')
    }
	else if(emails.value==" " ){
		message.push('Email can not be empty')
		alert(message)

	}
    

    



}











/*
function f1() {
	let name=document.getElementById('uname').value;
	//document.getElementsByTagName('usernames').innerHTML=name;
	
}

function f2() {
	document.getElementsByTagName('passwords').innerHTML=password;
	
}

function f3(email) {
	document.getElementsByTagName('gmails').innerHTML=email;
	
}
function f4(number) {
	document.getElementsByTagName('phonenumber').innerHTML=phone;
	
}



		function RegCheck( ) {
			let name=document.getElementById('name').value;
			if (name==NULL){
				document.getElementById('name').innerHTML="PLease enter name";
			}

			else{

				document.getElementById('name').innerHTML="";
			}
			
		}
	</script>
<?php
session_start();
if (!isset($_SESSION["uname"])) {
    session_destroy();
    header("location:login.html");
}
$u_name=$_SESSION['uname'];
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bus Mangaer Home </title>
</head>
<body>
	<h1 style="text-align: center;">Bus Manager Home </h1>
	<a href="Logout.php" style="align-self: right; color: red;">Logout</a>
	
	<hr >

	<h2 style="text-align: center;">--Welcome Bus Manager--</h2>

	<ul>
		<li> <a href="../views/addbus.html">Add Bus </a> </li>
		<br>
		<li><a href="UpdateBus.php">Update Bus</a></li>
		<br>
		<li><a href="DeleteBus.php">Delete Bus</a></li>
		<br>
		<li><a href="AddBusTicket.php">Add Bus Ticket</a></li>
		<br>
		<li><a href="UpdateBusTicket.php">Update Bus Ticket</a></li>
		<br>
		<li><a href="DeleteBusTciket.php">Delete Bus Tciket</a></li>
		<br>
		<li><a href="ViewBusTickets.php">View All booked Bus tickets</a></li>

	</ul>

	<img src="../Logos/busmanager.jpg" alt=" " align="right" width="50" height="60">



	<hr>

<p align="center">Copyright@2022</p>

<hr>




</body>
</html>
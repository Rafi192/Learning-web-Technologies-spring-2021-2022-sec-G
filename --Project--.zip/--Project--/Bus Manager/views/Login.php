<?php 
	session_start();
	//print_r($_SESSION);
?>
<html>
<!DOCTYPE html>
<html lang="en-US">
	<head>
		<title>Login</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	</head>
	<body>
		<fieldset>
			<legend>Login</legend>
		<form action="../controllers/login_verify.php" method="post" >
			<label for="usernames">Username</label><br>
			<input type="text" class="form-control" name="usernames" id="usernames" placeholder="Enter username"><br><br>
			<label for="passwords">Password</label><br>
			<input type="password" class="form-control" name="passwords" id="passwords" placeholder="Enter password"><br><br>
			<input type="submit" name="submit" class="submit_btn" value="Sign in">
			<script>
                    function showPass() {
                        var x = document.getElementById("pass");
                        if (x.type === "password") {
                            x.type = "text";
                        } else {
                            x.type = "password";
                        }
                    }
                </script>
		</form>
		<div class="forgot-password-section">
			<a href=" " class="text-color">Forgot your password?</a>
		</div>
		<div class="sign-up-section">
			<div class="account-section text-color">
				Do you have an account?
			</div><br>
			<div class="sign-up-button-area">

				<a  href="../views/registration.php"> <input type="submit" value="submit"  >  Sign up</a>
				
			</div>
			</fieldset>
	</body>
</html>
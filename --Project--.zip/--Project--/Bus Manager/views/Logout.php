<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    
    <title> Transport management </title>
</head>

<body>
    <?php
    session_start();

    if (isset($_SESSION['email'])) {
        session_destroy();
        header("location:Login.php");
    } else {
        header("location:Login.php");
    }
    ?>
</body>

</html>
<!DOCTYPE html>
<html>
<head>
	<title>Remove Bus </title>
</head>
<body>
	<form method="post" action="../controllers/RemoveBusCheck.php">
        <h2>Remove Bus</h2>
        <h5>Please enter Bus details</h5>
		<fieldset>
			<legend>Bus Details</legend>
			<table>
				<tr>
					<td>Bus name:</td>
					<td><input type="text" name="busname" value=""></td>
				</tr>
				<tr>
					<td>Bus number</td>
                    <td><input type="text" name="number" id="" value=""></td>
                    </tr>
				<tr>
					<td>Destination</td>
					<td><input type="text" name="destination" value=""></td>
				</tr>
				<td>Time</td>
					<td><input type="date" name="" value=""></td>
				</tr>
                    <tr>
					<td><br><input type="submit" name="submit" value="Remove"></td>
				</tr>
			</table>
		</fieldset>
	</form>
</body>
</html>
<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Bus Mangaer Home </title>
</head>
<body>
	<h1 style="text-align: center;">Bus Manager Home </h1>
	<a href="Logout.php" style="align-self: right; color:red ;">Logout</a>
	<hr >

	<h2 style="text-align: center;">--Welcome Bus Manager--</h2>

	<ul style="display:flex; justify-content:space-between; list-style:none; font-size:20px">
		<li> <a href="../views/addbus.html">Add Bus </a> </li>
		<br>
		<li><a href="addticket.php">Pre-book Bus Ticket</a></li>
		<br>
		<li><a href="registration.php">Registration</a></li>

		<li><a href="ViewBookTickets.html">View Booked Tickets </a></li>

		<li><a href="UpdateBus.php">Update Bus Tikcets</a></li>

		<li><a href=" "> Get Bus Reports</a></li>
		<li><a href=" RemoveBus.php"> Remove bus Tickets</a></li>

	</ul>

	<img src="../Logos/busmanager.jpg" alt=" "  width="100%" height="50%">



	<hr>

<p align="center">Copyright@2022</p>

<hr>




</body>
</html>
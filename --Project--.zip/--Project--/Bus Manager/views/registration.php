<?php include "../models/db.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
	<script defer src="../models/validation.js"></script>
</head>

<body>

	<form action="../controllers/create_user.php" method="post" >



        <h2>Add Customers</h2>
        <h5>Please enter Customer details</h5>
		<fieldset>
			<legend>Signup</legend>
			<table>
				<tr>
					<td>Username:</td>
					<td><input type="text" name="usernames" value="" id="uname" require></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input type="password" name="passwords" value="" id="pass" require></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td><input type="email" name="gmails" value="" id="emails" require></td>
				</tr>
				<tr>
					<td>Phone Number:</td>
					<td><input type="number" name="phonenumber" id="phone" require></td>
				</tr>
                <tr>
					<td><br><input type="submit" name="submit" value="Register"></td>
				</tr>
			</table>
		</fieldset>
	</form>

</body>
</html>
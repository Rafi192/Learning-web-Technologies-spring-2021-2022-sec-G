<?php

    if(isset($_POST['submit'])){
        $comment= $_POST['comment'];
        $date=$_POST['Date'];
  


        if($comment != "" && $date!=""){

                            $myfile = fopen('../models/CancelDetails.txt', 'r');

                            $id=0;

                            while(!feof($myfile)){

       

                                $data = fgets($myfile);

                                $id++;

                            }

       

                            $myfile = fopen('../models/CancelDetails.txt', 'a');
                            $myuser=$date."\r\n". $comment."\r\n";

                            //$myuser =$comment."\r\n";

                            
                            

                            fwrite($myfile, $myuser);

                            fclose($myfile);

                            echo"Thanks for your comment";

                            header('location: ../views/CancelTicket.html');

                        }

        }
        else{

            echo "invalid comment....";

    }

?>
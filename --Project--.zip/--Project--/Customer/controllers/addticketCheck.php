<?php 


	if(isset($_POST['submit'])){

		//$Add	= $_POST['AddBus'];
        $comment=$_POST['comment'];


		if($comment!=""){
                            $myfile = fopen('../models/addticket.txt', 'r');
                            $id=0;
                            while(!feof($myfile)){
        
                                $data = fgets($myfile);
                                $id++;
                            }
        
                            $myfile = fopen('../models/addticket.txt', 'a');
                            $myuser =$comment."\r\n" ;
                            fwrite($myfile, $myuser);
                            fclose($myfile);
        
                            header('location: ../views/dashboard.php');
                            echo "Ticket given!!!";
                        }else{
			echo "invalid Ticket....";
		}
	}
?>
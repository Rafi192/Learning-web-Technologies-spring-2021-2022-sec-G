<?php
    include "../models/db.php";
    if(isset($_POST["submit"])){
        $minimum=2;
        $usernames= $_POST["usernames"];
        $passwords= $_POST["passwords"];
        $gmails= $_POST["gmails"];
        if(strlen($passwords) < $minimum){
            echo "Password is too much short";
        }
    $query = "INSERT INTO customer(usernames,passwords,gmails)";
    $query .= "VALUES ('$usernames','$passwords','$gmails')";
    $result = mysqli_query($connection,$query);
    }

?>
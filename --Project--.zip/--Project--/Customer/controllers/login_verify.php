<?php
if(isset($_POST["submit"])){
	$minimum=2;
	$name = array("sonia");
	$usernames= $_POST["usernames"];
	$passwords= $_POST["passwords"];
	if(strlen($passwords) < $minimum){
		echo "Password is too much short";
	}
	if(!in_array($usernames,$name)){
		echo "Sorry, you're not allow.<br>";
	}else{
		header('location: ../views/dashboard.php');
	}
	$connection = mysqli_connect('localhost','root','','transport');
	if($connection){
		echo "we are connected with database.";
	}else{
		echo "Invalid user";
	}
}

?>
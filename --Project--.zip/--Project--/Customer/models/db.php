<?php
	$connection = mysqli_connect('localhost','root','','transport');
	if($connection){
        echo "Customer added";
		// header('location: ../views/dashboard.php');
	}else{
        die("Database connection failed");
    }
    

?>
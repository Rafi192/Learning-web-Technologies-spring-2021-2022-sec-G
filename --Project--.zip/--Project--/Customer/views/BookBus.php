<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Final project</title>
    <style type="text/css">
        table,
        th,
        td {
            border: 1px solid #dddddd;
            border-collapse: collapse;
            padding: 12px;
            text-align: center;
            border-style: solid;
        }

        .tableStyle {
            width: 100%;
        }

        .center {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .red {
            color: red;
        }

        .green {
            color: green;
        }
    </style>

</head>
<body>
    <?php
    session_start();
    include 'Header.php';
    if (!isset($_SESSION['email'])) {
        header("location:Login.php");
    }
    ?>

    <form method="post">

        Go back to : <a href="Customer_Home.php">Home</a><br><br>
        <fieldset>
            <legend><b>BOOK BUS TICKETS</b></legend><br>
            <table class="tableStyle">
                <tr>
                    <th>Bus ID</th>
                    <th>Bus Name</th>
                    <th>Bus Location</th>
                    <th>Ticket ID</th>
                    <th>Transport Type</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>

                //file write
            </table>


</body>
</html>



<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Final project</title>

	<style type="text/css">
        table,
        th,
        td {
            border: 1px solid #dddddd;
            border-collapse: collapse;
            padding: 12px;
            text-align: center;
            border-style: solid;
        }

        .tableStyle {
            width: 100%;
        }

        .center {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .red {
            color: red;
        }

        .green {
            color: green;
        }
    </style>
</head>
<body>


<form method="post">

        Go back to : <a href="Customer_Home.php">Home</a><br><br>
        <fieldset>
            <legend><b>BOOK TRAIN TICKETS</b></legend><br>
            <table class="tableStyle">
                <tr>
                    <th>Train ID</th>
                    <th>Train Name</th>
                    <th>Train Location</th>
                    <th>Ticket ID</th>
                    <th>Transport Type</th>
                    <th>From</th>
                    <th>To</th>
                    <th>Price</th>
                    <th>Date</th>
                    <th>Time</th>
                </tr>

            </table>

</body>
</html>

?>
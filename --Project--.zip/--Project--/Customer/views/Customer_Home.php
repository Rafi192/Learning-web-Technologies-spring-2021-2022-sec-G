<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title> Transportation management system/Customer</title>

	<style>
        * {
            box-sizing: border-box;
        }

        .row {
            display: flex;
        }

        .column {
            flex: 50%;
            padding: 10px;
            height: 50%;
        }
    </style>
</head>
<body>
<span style="display:inline-block; width:100%;text-align:left; height: 100%; padding:10px; border-right:2px solid black">
       
        <hr>
        <ul>
            <li><a href="Book_Bus_Tickets.php">Book bus tickets</a></li>
            <li><a href="Book_Train_Tickets.php">Book train tickets</a></li>
            <li><a href="Book_Plane_Tickets.php">Book plain tickets</a></li>
            <li><a href="View_Booked_Tickets.php">View booked tickets</a></li>
            <li><a href="Cancel_Booked_Tickets.php">Cancel booked tickets</a></li>
        </ul>
    </span>

    <span style="display:inline-block; width:100%; height:100%; text-align:center"><a href="Logout.php">Logout</a>
    </span>

	<span style="display:inline-block; width:100%;text-align:left; height: 40%;">
	<h1 style="text-align: center";>Transportation Management </h1>
	<a href="registration.html" title="" style="text-decoration: none" ; target="_blank"  >|Registrater</a>
	<a href="Login.php" title="" style="text-decoration: none" ; target="_blank" >| Login</a>
	<a href="Customer_Home.php" title="" style="text-decoration: none" ; target="_blank" >|Home</a>
	<a href="Logout.php" title="" style="text-decoration: none"; target="_blank" >Logout</a>

	<hr>

<img src="../Logos/Home2.jpg" alt=" " align="center" width="50% "; height="100%" >
</span>

<hr>

<p align="center">Copyright@2022</p>

<hr>
	


</body>
</html>
function CheckName(){
if(document.getElementById("name").value==""){
    alert("Null");
    document.getElementById("nameErr").innerHTML="*name can not be empty";

    document.getElementById("name").style.borderColor="red";
}
else if (document.getElementById("name").value.split(' ').lenght<2){
    document.getElementById("nameErr").innerHTML = "*Full name must be at least 2 words";
        document.getElementById("name").style.borderColor = "red";
} else {
    document.getElementById("name").innerHTML = "";

}

}

function checkEmail() {
    if (document.getElementById("email").value == "") {

    document.getElementById("emailErr").innerHTML = "* please enter rigth email";

        document.getElementById("email").style.borderColor = "red";

    } else if (!document.getElementById("email").value.match(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/)) {

    document.getElementById("emailErr").innerHTML = "*please enter a valid email address";

        document.getElementById("email").style.borderColor = "red";
    } else {
        document.getElementById("emailErr").innerHTML = "";

        document.getElementById("email").style.borderColor = "purple";
    }
}

function checkPass() {
    if (document.getElementById("pass").value == "") {

    document.getElementById("passErr").innerHTML = "*Password cannot be empty";

        document.getElementById("pass").style.borderColor = "red";
    }
    else if (document.getElementById("pass").value.length < 6) {

     document.getElementById("passErr").innerHTML = "*Password must not be less than six (6) characters";
        document.getElementById("pass").style.borderColor = "red";
    }else{
        document.getElementById("passErr").innerHTML = "";
    }
}
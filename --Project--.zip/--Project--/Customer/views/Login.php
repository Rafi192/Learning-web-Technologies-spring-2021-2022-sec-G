<?php 
	session_start();
	//print_r($_SESSION);
	if(isset($_SESSION['usernames'])){

		header("location: ../controllers/create_user.php");

	}	

?>
<html>
<!DOCTYPE html>
<html lang="en-US">
	<head>
		<title>Login</title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<script > 
	
	function validate(){

		var name=document.getElementById('usernames').value;
		var pass=docuemnt.getElementById('passwords').value;

		if (name==""){
			document.getElementById("message").innerHTML="Enter name";
			return false;

			//conssole.log("please enter name");conssole.log("please enter name");
			//alert("please enter name");
		}
		else if(pass==" "){
			document.getElementById("message").innerHTML="Enter passeord";
			return false;
			//conssole.log("please enter name");

			//alert("empty password");
		}


}

	</script>

	</head>
	<body>
		<fieldset>
			<legend>Login</legend>
		
			<form action="  " method="post" onsubmit="return validate() " >
			<label for="usernames">Username</label><br> <p id="username"> </p>
			<input type="text" class="form-control" name="usernames" id="usernames" placeholder="Enter username" require><br><br>
			<label for="passwords">Password</label><br><br> <p id="password">  </p>
			<input type="password" class="form-control" name="passwords" id="passwords" placeholder="Enter password"><br><br>
		
			<p id="pass"> </p>
			
			<input type="submit" name="submit" class="submit_btn" value="Sign in">
			<p id="message"></p>
		</form>
		<div class="forgot-password-section">
			<a href="#" class="text-color">Forgot your password?</a>
		</div>
		<div class="sign-up-section">
			<div class="account-section text-color">
				Do you have an account?
			</div><br>
			<div class="sign-up-button-area">
				<a href="registration.php">Sign up</a>
			</div>
			</fieldset>
	</body>
</html>
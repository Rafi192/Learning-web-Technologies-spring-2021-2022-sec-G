
<!DOCTYPE html>
<html lang="en">


<head>

    <meta charset="UTF-8">

    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Add ticket</title>

</head>


<body>

    <form method="post" action="../controllers/addticketCheck.php">

    <label for="method">Bus name</label>

    <select  name="method" id="" name="AddBus">

  <optgroup label="Bus Options">

    <option value="3">SR Plus</option>

  </optgroup>
  
  
 </select><br><br>
 <label for="method">Bus type</label>
 <select name="method" id="">
 <optgroup label="Bus Type">

<option value="1">Non-AC</option>

<option value="2">AC</option>

<option value="3">Scania</option>

</optgroup>
 </select><br><br><br>
    <textarea name="comment" id="" cols="30" rows="2"></textarea><br>
    <input type="submit" name="comment" value="Submit">
</form>

</body>

</html>
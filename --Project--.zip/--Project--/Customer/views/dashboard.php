<?php
session_start();
// if (!isset($_SESSION["uname"])) {
//     session_destroy();
//     header("location:login.html");
// }
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
	<title>
	<hr> Transportation management system/Customer<hr> </title>

</head>
<body>
	<h1 style="text-align: center";>Transportation Management </h1>
	<h3><i>Welcome Sonia</i></h3>
	<a href="addticket.php" title="" style="text-decoration: none" ; >Pre-book Bus Ticket</a>
	<a href="registration.php" title="" style="text-decoration: none" ;   >|Registrater</a>
	<br><br>
	<a href="dashboard.php" title="" style="text-decoration: none" ;  >Home</a>
	<a href="Logout.php" title="" style="text-decoration: none";  >|Logout</a>

	<a href="../views/AirTicket.html" title="" style="text-decoration: none";  >|Buy Air tickets</a>

	<a href="CancelTicket.html" title="" style="text-decoration: none"; >|Cancel Tickets</a>

	<a href="Logoout.php" title="" style="text-decoration: none";  >|Edit Profile</a>

	<a href="Logoout.php" title="" style="text-decoration: none"; target="_blank" >|View Profile picture</a>
	<a href="showdetails.php" title="" style="text-decoration: none";  >|Show customer details</a>





	<hr>

<img src="../Logos/Home2.jpg" alt=" " align="center" width="100% "; height="100%" >

<hr>

<p align="center">Copyright@2022</p>

<hr>
	


</body>
</html>
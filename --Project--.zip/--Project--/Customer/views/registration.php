<?php include "../models/db.php";
?>
<!DOCTYPE html>
<html>
<head>
	<title>Signup</title>
	<script src="../views/FormValidation.js"></script>
</head>
<body>

	<form action="../controllers/create_user.php" method="post" onsubmit=" return CheckName()">



        <h2>Add Customers</h2>
        <h5>Please enter Customer details</h5>
		<fieldset>
			<legend>Signup</legend>
			<table>
				<tr>
					<td>Username:</td>
					<td><input id="name" type="text" name="usernames" value=""></td>
				</tr>
				<tr>
					<td>Password:</td>
					<td><input id="pass" type="password" name="passwords" value=""></td>
				</tr>
				<tr>
					<td>Email:</td>
					<td><input id="email" type="email" name="gmails" value=""></td>
				</tr>
                    <tr>
					<td><br><input type="submit" name="submit" value="Register"></td>
				</tr>
			</table>
		</fieldset>
	</form>
</body>
</html>
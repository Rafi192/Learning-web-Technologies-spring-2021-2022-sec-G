<?php

$conn= mysqli_connect('localhost','root','','Customer');

if($conn){

	echo "Coonection successful";
}
else{
	echo "erroer in connection";

}

$sql="insert into customerTable(Id,UserName,password,Email) values('4097','Rafiul','Rafi40977!!?','Rafi@gmail.com',) ";
$Query=mysqli_query($conn,$sql);



if ($Query) {
	echo "Data Inserted correctly";
	// code...
}
else{
	echo "Not inserted";
 }
 //$sql="select *  from Customer";
//$QueryResult = mysqli_query($con, $sql);

/*$row1= mysqli_fetch_assoc($QueryResult);
//$row2 = mysqli_fetch_assoc($QueryResult);

print_r($row1);
//print_r($row2);

	while ($row = mysqli_fetch_assoc($QueryResult)) {
		print_r($row);
		echo "<br>";
	}

*/

?>